const fs = require('fs')
      
    // Edit cypress.env.json
    const cypressEnvJsonRead = "./cypress/cypress.env.json"
    const cypressEnvJsonWrite = "./cypress.env.json"
    editJSON(cypressEnvJsonRead, cypressEnvJsonWrite);

    // Edit cypress.json
    const cypressJsonRead = "./cypress/cypress.json"
    const cypressJsonWrite = ".//cypress.json"
    editJSON(cypressJsonRead, cypressJsonWrite);


    function editJSON(read, write) {
    var file = {}
    try {
        file = require(read)
    } catch(e) {
        file = {}
    }

    file.projectId = "#{params[:automate_session_id]}"
    file.execTimeout = 0;
    file.taskTimeout = 0;

    fs.writeFile(write, JSON.stringify(file), function writeJSON(err) {
        if (err) return console.log(err);
        console.log('writing to ' + write);
    });
    }

