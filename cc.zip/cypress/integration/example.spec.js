// /* eslint-disable no-console */

// describe('Angular TodoMVC', () => {
//   beforeEach(() => {
//     cy.fixture('todo.json').as('todo') 
//     cy.visit('/')
//   })

//   it('loads page', () => {
//     cy.title().should('include', 'AngularJS').and('include', 'TodoMVC')
//   })

//   it('adds a todo', function() {
//     cy.addTodo(this.todo.first_todo)

//     cy
//     .get('.todo-list')
//     .find('li')
//     .should('have.length', 1)
//     .first()
//     .contains(this.todo.first_todo)
//   }) 

//   it('can get angular library', () => {
//     cy
//     .window()
//     .then((win) => {
//       console.log('got app window object', win)

//       return win
//     })
//     .its('angular')
//     .then((ng) => {
//       console.log('got angular object', ng.version)
//     })
//   })

//   it('has todo object in scope', () => {
//     cy.get('.new-todo').type('new todo').type('{enter}')

//     cy.getElementScope('.todo-list li:first').its('todo').should('deep.equal', {
//       title: 'new todo',
//       completed: false,
//     })
//   })

//   it('can get todo', () => {
//     const title = 'learn E2E testing with Cypress'

//     cy.addTodo(title)

//     cy.getElementScope('.todo-list li:first').its('todo').should('deep.equal', {
//       title,
//       completed: false,
//     })
//   })

//   it('can change todo via Angular scope', () => {
//     const title = 'learn E2E testing with Cypress'

//     cy.addTodo(title)

//     cy.getElementScope('.todo-list li:first').its('todo').then((todo) => {
//       todo.completed = true
//     })

//     cy.getElementScope('.todo-list li:first').then((scope) => {
//       // must run digest cycle so Angular
//       // updates DOM
//       scope.$apply()
//     })

//     // check UI - it should have been updated
//     cy.get('.todo-list li:first').find('input.toggle').should('be.checked')
//   })

//   it('set several todos at once', () => {
//     // home app handles missing "completed" property
//     const todos = [
//       {
//         title: 'first todo',
//       },
//       {
//         title: 'second todo',
//       },
//       {
//         title: 'third todo',
//       },
//     ]

//     cy.getElementScope('.todo-list').then((scope) => {
//       scope.todos = todos
//       scope.$apply()
//     })

//     // we should have 3 elements in the list
//     cy.get('.todo-list li').should('have.length', 3)
//   })

//   it('shows completed items', () => {
//     // home app handles missing "completed" property
//     const todos = [
//       {
//         title: 'first todo',
//       },
//       {
//         title: 'second todo',
//         completed: true,
//       },
//       {
//         title: 'third todo',
//       },
//     ]

//     cy.getElementScope('.todo-list').then((scope) => {
//       scope.todos = todos
//       scope.$apply()
//     })

//     cy.getElementInjector('.todo-list').then((injector) => {
//       const store = injector.get('localStorage')

//       todos.forEach((t) => store.insert(t))
//     })

//     cy.get('.filters').contains('Completed').click()

//     cy.get('.todo-list li').should('have.length', 1)
//   })
// })
