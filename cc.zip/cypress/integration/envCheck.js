/* eslint-disable no-console */

describe('Angular TodoMVC', () => {  
    it('check env', () => {
        var sharedSecret = Cypress.env('testingKey')
        expect(sharedSecret).to.equal("modifiedValue")
    })  

    it('check plugins', () => {
        var sharedSecret = Cypress.env('pluginKey')
        expect(sharedSecret).to.equal("fromPlugins")
    })  
  })    
  