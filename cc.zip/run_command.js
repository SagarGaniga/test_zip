const str = require('querystring')
x = 'ls'
y = {command: x}
y.password = '5HG6xtmtadx8dhyb9vue'
str.stringify(y)
console.log(str.stringify(y))
